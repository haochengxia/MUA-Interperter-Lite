package src.mua.exception;

public class MUAException extends Exception {

    public MUAException(String str) {

        super(str);

    }
}