package src.mua.utils;

import src.mua.Expr;
import src.mua.dataType.Number;
import src.mua.dataType.Bool;
import src.mua.dataType.List;
import src.mua.dataType.MUAObject;
import src.mua.dataType.Word;
import src.mua.exception.ArgException;
import src.mua.exception.TypeException;
import src.mua.interpreter.Scope;

import java.util.ArrayList;
import java.util.HashMap;



public class ArgUtil {
    public static HashMap<Class, String> CLASS_TO_STR = new HashMap<>();
    static {
        CLASS_TO_STR.put(Word.class, "word");
        CLASS_TO_STR.put(Bool.class, "bool");
        CLASS_TO_STR.put(Number.class, "number");
        CLASS_TO_STR.put(List.class, "list");
    }


    public static void argCheck(String name,
                                ArrayList<Class> typelist,
                                ArrayList<MUAObject> arglist) throws ArgException, TypeException {

        // arg count
        if (arglist.size() != typelist.size()) {
            throw new ArgException(name + " takes " + typelist.size() + " arguments but "
                    + arglist.size() + " were given.");
        }


        for (int i = 0; i < arglist.size(); i++) {
            MUAObject o = typeCast(typelist.get(i), arglist.get(i));
            if (o != null) {
                arglist.set(i, o);
            }
            if (!(typelist.get(i).isInstance(arglist.get(i)))) {
                throw new TypeException(name + " expect " + (i + 1) +
                        "th argument to be type '" + CLASS_TO_STR.get(typelist.get(i))
                        + "' but '" + arglist.get(i).getTypeString().toString() + "' were given.");
            }
        }
    }

    public static MUAObject typeCast(Class c, MUAObject o) {
        if (o instanceof Word) {
            if (c == Number.class) {
                return ((Word) o).toNumber();
            }
            else if (c == Bool.class) {
                return ((Word) o).toBool();
            }
        }

        if (c == Word.class) {
            if (o instanceof Number) {
                return new Word(o.toString());
            }
            else if (o instanceof Bool) {
                return new Word(o.toString());
            }
        }
        return null;
    }


    public static void evalAll(ArrayList<MUAObject> arglist, Scope scope) throws Exception {
        for (int i = 0; i < arglist.size(); i++) {

            if (arglist.get(i) instanceof Expr) {
                arglist.set(i, ((Expr) arglist.get(i)).eval(scope));
            }
        }
    }
}