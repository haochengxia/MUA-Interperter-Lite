package src.mua;

import src.mua.Interpreter.Interpreter;


public class Main {

        public static void main(String[] args)  {
               Interpreter MuaInterpreter = new Interpreter();
               MuaInterpreter.Run();
    }
}
